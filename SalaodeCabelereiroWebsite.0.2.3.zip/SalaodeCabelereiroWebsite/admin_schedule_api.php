<?php
require_once 'database.php';

header('Content-Type: application/json');

$method = $_SERVER['REQUEST_METHOD'];

switch ($method) {
    case 'GET':
        // List all available times
        $stmt = $pdo->prepare("SELECT * FROM horariodisponivel ORDER BY data, hora_inicio");
        $stmt->execute();
        $times = $stmt->fetchAll(PDO::FETCH_ASSOC);
        echo json_encode(['success' => true, 'available_times' => $times]);
        break;

    case 'DEBUGPOST':
        // Debug endpoint to echo back POST data
        $data = json_decode(file_get_contents('php://input'), true);
        error_log("DEBUGPOST data received: " . print_r($data, true));
        echo json_encode(['success' => true, 'received_data' => $data]);
        break;

    case 'POST':
        // Add new available times
        $data = json_decode(file_get_contents('php://input'), true);
        error_log("POST data received: " . print_r($data, true));
        if (!$data || !isset($data['date']) || !isset($data['time'])) {
            error_log("Invalid input in POST data");
            echo json_encode(['success' => false, 'message' => 'Invalid input']);
            exit;
        }

        $date = $data['date']; // string "YYYY-MM-DD"
        $time = $data['time']; // string "HH:MM"

        // Validate that the datetime is at least 1 hour in the future and within 15 days from now
        $datetime = DateTime::createFromFormat('Y-m-d H:i', "$date $time");
        $now = new DateTime();
        $now->modify('+1 hour');
        $maxDate = new DateTime();
        $maxDate->modify('+15 days');
        if ($datetime < $now) {
            echo json_encode(['success' => false, 'message' => 'O horário deve ser registrado com pelo menos 1 hora de antecedência']);
            exit;
        }
        if ($datetime > $maxDate) {
            echo json_encode(['success' => false, 'message' => 'O horário não pode ser registrado para mais de 15 dias no futuro']);
            exit;
        }

        // Check if the time slot already exists
        $checkStmt = $pdo->prepare("SELECT COUNT(*) FROM horariodisponivel WHERE data = ? AND hora_inicio = ?");
        $checkStmt->execute([$date, $time . ':00']);
        $count = $checkStmt->fetchColumn();
        if ($count > 0) {
            echo json_encode(['success' => false, 'message' => 'Horário já registrado']);
            exit;
        }

        // Insert into database
        $hora_inicio = $time . ':00';
        $hora_inicio_dt = DateTime::createFromFormat('H:i:s', $hora_inicio);
        $hora_fim_dt = clone $hora_inicio_dt;
        $hora_fim_dt->modify('+30 minutes');
        $hora_fim = $hora_fim_dt->format('H:i:s');

        $insertStmt = $pdo->prepare("INSERT INTO horariodisponivel (data, hora_inicio, hora_fim, disponivel) VALUES (?, ?, ?, 1)");
        $insertStmt->execute([$date, $hora_inicio, $hora_fim]);

        echo json_encode(['success' => true, 'message' => 'Horário adicionado com sucesso']);
        break;

    case 'DELETE':
        // Delete available time by id
        // Fix: parse_str does not work well with fetch DELETE, use $_GET instead
        $id = $_GET['id'] ?? null;
        if (!$id) {
            echo json_encode(['success' => false, 'message' => 'ID is required']);
            exit;
        }
        $deleteStmt = $pdo->prepare("DELETE FROM horariodisponivel WHERE id = ?");
        $deleteStmt->execute([$id]);
        echo json_encode(['success' => true, 'message' => 'Time deleted']);
        break;

    default:
        echo json_encode(['success' => false, 'message' => 'Invalid request method']);
        break;
}
?>
