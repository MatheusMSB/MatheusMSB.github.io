<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');

$host = 'localhost';
$user = 'root';
$password = 'ThoAin456!';
$dbname = 'hairsalon';

$conn = new mysqli($host, $user, $password, $dbname);
if ($conn->connect_error) {
    die(json_encode(["error" => "Erro na conexão: " . $conn->connect_error]));
}

$sql = "
SELECT 
    agendamento.id,
    servico.nome AS servico,
    user.username AS cliente,
    agendamento.data,
    agendamento.hora_inicio,
    agendamento.hora_fim
FROM 
    agendamento
LEFT JOIN cliente ON agendamento.cliente_id = cliente.id
LEFT JOIN user ON cliente.user_id = user.id
LEFT JOIN servico ON agendamento.servico_id = servico.id
ORDER BY 
    agendamento.data ASC, agendamento.hora_inicio ASC
";

$result = $conn->query($sql);

$agendamentos = [];

if ($result) {
    while ($row = $result->fetch_assoc()) {
        $agendamentos[] = [
            "title" => ($row['servico'] ?? 'Sem Serviço') . " - " . ($row['cliente'] ?? 'Sem Cliente'),
            "start" => $row['data'] . "T" . $row['hora_inicio'],
            "end" => $row['data'] . "T" . $row['hora_fim']
        ];
    }
    echo json_encode($agendamentos);
} else {
    echo json_encode(["error" => $conn->error]);
}

$conn->close();
?>
