<?php
require_once 'database.php';
session_start();

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST');

// Verificar se o cliente está logado
if (!isset($_SESSION['user']['id'])) {
    http_response_code(401);
    echo json_encode([
        'success' => false,
        'message' => 'Cliente não autenticado.'
    ]);
    exit;
}

$user_id = $_SESSION['user']['id'];

$data = $_POST['date'] ?? NULL;
$hora = $_POST['time'] ?? NULL;
$servico = $_POST['service'] ?? NULL;

if ($data && $hora && $servico) {
    // Get cliente.id from cliente table using user_id
    $sql_cliente = "SELECT id FROM cliente WHERE user_id = ?";
    $stmt_cliente = $pdo->prepare($sql_cliente);
    $stmt_cliente->execute([$user_id]);
    $cliente = $stmt_cliente->fetch();

    if (!$cliente) {
        http_response_code(400);
        echo json_encode([
            'success' => false,
            'message' => 'Cliente não encontrado para o usuário logado.'
        ]);
        exit;
    }

    $cliente_id = $cliente['id'];
    $hora_fim = date('H:i:s', strtotime($hora . ' +1 hour'));

    $sql = "INSERT INTO agendamento (cliente_id, servico_id, data, hora_inicio, hora_fim) 
            VALUES (?, ?, ?, ?, ?)";

    try {
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$cliente_id, $servico, $data, $hora, $hora_fim]);
        http_response_code(200);
        echo json_encode([
            'success' => true,
            'message' => 'Agendamento realizado com sucesso!'
        ]);
    } catch (PDOException $e) {
        http_response_code(500);
        echo json_encode([
            'success' => false,
            'message' => 'Erro ao realizar agendamento: ' . $e->getMessage()
        ]);
    }
} else {
    http_response_code(400);
    echo json_encode([
        'success' => false,
        'message' => 'Dados incompletos para agendamento.'
    ]);
}
?>
