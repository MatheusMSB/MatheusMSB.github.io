<?php
require_once 'database.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $userId = $_POST['user_id'] ?? null;
    $service = $_POST['service'] ?? null;
    $datetime = $_POST['datetime'] ?? null;

    if ($userId && $service && $datetime) {
        $stmt = $pdo->prepare("INSERT INTO appointments (user_id, service, appointment_datetime, status) VALUES (?, ?, ?, 'Pending')");
        if ($stmt->execute([$userId, $service, $datetime])) {
            echo json_encode(['success' => true, 'message' => 'Appointment scheduled successfully.']);
        } else {
            echo json_encode(['success' => false, 'message' => 'Failed to schedule appointment.']);
        }
    } else {
        echo json_encode(['success' => false, 'message' => 'Missing required fields.']);
    }
} else {
    echo json_encode(['success' => false, 'message' => 'Invalid request method.']);
}
?>
