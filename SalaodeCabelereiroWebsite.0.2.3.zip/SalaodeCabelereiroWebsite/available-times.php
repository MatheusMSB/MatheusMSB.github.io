<?php
require_once 'database.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $date = $_GET['date'] ?? null;

    if (!$date) {
        echo json_encode(['success' => false, 'message' => 'Date parameter is required']);
        exit;
    }

    $stmt = $pdo->prepare("SELECT * FROM horariodisponivel WHERE data = ? AND disponivel = 1 ORDER BY hora_inicio");
    $stmt->execute([$date]);
    $availableTimes = $stmt->fetchAll();

    echo json_encode(['success' => true, 'available_times' => $availableTimes]);
} else {
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
}
?>
