<?php
require_once 'bootstrap.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Atualizar
    $id = intval($_POST['id']);
    $nome = trim($_POST['nome']);
    $descricao = trim($_POST['descricao']);
    $quantidade = floatval($_POST['quantidade_disponivel']);

    try {
        $stmt = $pdo->prepare("UPDATE produto SET nome = :nome, descricao = :descricao, quantidade_disponivel = :quantidade WHERE id = :id");
        $stmt->execute([
            ':nome' => $nome,
            ':descricao' => $descricao,
            ':quantidade' => $quantidade,
            ':id' => $id
        ]);
        header("Location: gerenciar_produtos.html");
        exit;
    } catch (Exception $e) {
        echo "Erro ao editar produto: " . $e->getMessage();
    }
} elseif (isset($_GET['id'])) {
    // Mostrar formulário
    $id = intval($_GET['id']);
    $stmt = $pdo->prepare("SELECT * FROM produto WHERE id = :id");
    $stmt->execute([':id' => $id]);
    $produto = $stmt->fetch();

    if (!$produto) {
        echo "Produto não encontrado.";
        exit;
    }
    ?>
    <!DOCTYPE html>
    <html lang="pt-BR">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Editar Produto - Stylus Cabeleireiro</title>
        <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600&display=swap" rel="stylesheet">
        <style>
            :root {
                --primary-color: #388e3c;
                --primary-dark: #2e7d32;
                --light-bg: #f8f9fa;
                --white: #ffffff;
                --danger: #dc3545;
            }
            
            body {
                font-family: 'Poppins', sans-serif;
                margin: 0;
                padding: 0;
                background-color: var(--light-bg);
                color: #333;
            }
            
            header {
                background-color: var(--primary-dark);
                color: var(--white);
                text-align: center;
                padding: 3px 0;
                box-shadow: 0 2px 10px rgba(0,0,0,0.1);
                border-bottom: 2px solid var(--primary-color);
            }
            
            header h1 {
                color: var(--white);
            }
            
            .container {
                max-width: 600px;
                margin: 30px auto;
                background: var(--white);
                padding: 25px;
                border-radius: 10px;
                box-shadow: 0 5px 15px rgba(0,0,0,0.05);
            }
            
            h2 {
                color: var(--primary-dark);
                margin-bottom: 25px;
                text-align: center;
            }
            
            label {
                display: block;
                margin-bottom: 8px;
                font-weight: 500;
                color: #555;
            }
            
            input, textarea {
                width: 100%;
                padding: 10px 15px;
                border: 1px solid #ddd;
                border-radius: 6px;
                font-family: 'Poppins', sans-serif;
                margin-bottom: 15px;
            }
            
            textarea {
                min-height: 100px;
                resize: vertical;
            }
            
            button {
                padding: 12px 20px;
                background-color: var(--primary-color);
                color: var(--white);
                border: none;
                border-radius: 6px;
                font-weight: 500;
                cursor: pointer;
                transition: all 0.3s;
                display: block;
                width: 100%;
            }
            
            button:hover {
                background-color: var(--primary-dark);
            }
            
            .btn-secondary {
                background-color: #6c757d;
                margin-top: 15px;
            }
            
            .btn-secondary:hover {
                background-color: #5a6268;
            }
        </style>
    </head>
    <body>
        <header>
            <h1>Editar Produto</h1>
        </header>
        <div class="container">
            <form method="POST" action="editar_produto.php">
                <input type="hidden" name="id" value="<?= $produto['id'] ?>">
                <label for="nome">Nome:</label>
                <input type="text" id="nome" name="nome" value="<?= htmlspecialchars($produto['nome']) ?>" required>
                
                <label for="descricao">Descrição:</label>
                <textarea id="descricao" name="descricao"><?= htmlspecialchars($produto['descricao']) ?></textarea>
                
                <label for="quantidade_disponivel">Quantidade:</label>
                <input type="number" id="quantidade_disponivel" name="quantidade_disponivel" value="<?= $produto['quantidade_disponivel'] ?>" required>
                
                <button type="submit">Salvar Produto</button>
            </form>
            <button class="btn-secondary" onclick="window.location.href='gerenciar_produtos.html'">Voltar para Gestão de Produtos</button>
        </div>
    </body>
    </html>
    <?php
} else {
    echo "ID do produto não fornecido.";
}
?>
