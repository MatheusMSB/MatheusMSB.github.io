<?php
require_once 'bootstrap.php';

if (!isset($_GET['id'], $_GET['tipo'])) {
    die("Parâmetros inválidos.");
}

$servico_id = $_GET['id'];
$tipo_cabelo = $_GET['tipo'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nome = trim($_POST['nome']);
    $preco = $_POST['preco'];
    $duracao = $_POST['duracao'];
    $produto = trim($_POST['produto']);
    $quantidade = $_POST['quantidade'];

    try {
        $pdo->beginTransaction();

        // Atualiza serviço
        $stmt = $pdo->prepare("UPDATE servico SET nome = :nome, preco = :preco, duracao = :duracao WHERE id = :id");
        $stmt->execute([
            ':nome' => $nome,
            ':preco' => $preco,
            ':duracao' => $duracao,
            ':id' => $servico_id
        ]);

        // Atualiza ou cria produto
        $stmt = $pdo->prepare("SELECT id FROM produto WHERE nome = :nome LIMIT 1");
        $stmt->execute([':nome' => $produto]);
        $produtoData = $stmt->fetch();

        if (!$produtoData) {
            $stmt = $pdo->prepare("INSERT INTO produto (nome, quantidade_disponivel) VALUES (:nome, 0)");
            $stmt->execute([':nome' => $produto]);
            $produto_id = $pdo->lastInsertId();
        } else {
            $produto_id = $produtoData['id'];
        }

        // Atualiza consumo
        $stmt = $pdo->prepare("UPDATE consumoproduto SET produto_id = :produto_id, quantidade_usada = :quantidade WHERE servico_id = :servico_id AND tipo_cabelo = :tipo_cabelo");
        $stmt->execute([
            ':produto_id' => $produto_id,
            ':quantidade' => $quantidade,
            ':servico_id' => $servico_id,
            ':tipo_cabelo' => $tipo_cabelo
        ]);

        $pdo->commit();
        header("Location: listar_servicos.php");
        exit;
    } catch (Exception $e) {
        $pdo->rollBack();
        die("Erro ao atualizar: " . $e->getMessage());
    }
} else {
    // Busca dados para exibir no formulário
    $stmt = $pdo->prepare("
        SELECT s.nome, s.preco, s.duracao, p.nome AS produto, c.quantidade_usada
        FROM servico s
        JOIN consumoproduto c ON c.servico_id = s.id
        JOIN produto p ON p.id = c.produto_id
        WHERE s.id = :id AND c.tipo_cabelo = :tipo
    ");
    $stmt->execute([
        ':id' => $servico_id,
        ':tipo' => $tipo_cabelo
    ]);
    $dados = $stmt->fetch();

    if (!$dados) {
        die("Serviço não encontrado.");
    }
}
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Editar Serviço - Stylus Cabeleireiro</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600&display=swap" rel="stylesheet" />
    <style>
        :root {
            --primary-color: #388e3c;
            --primary-dark: #2e7d32;
            --light-bg: #f8f9fa;
            --white: #ffffff;
            --danger: #dc3545;
        }
        body {
            font-family: 'Poppins', sans-serif;
            margin: 0;
            padding: 0;
            background-color: var(--light-bg);
            color: #333;
        }
        header {
            background-color: var(--primary-dark);
            color: var(--white);
            text-align: center;
            padding: 3px 0;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            border-bottom: 2px solid var(--primary-color);
        }
        header h1 {
            color: var(--white);
        }
        .container {
            max-width: 600px;
            margin: 30px auto;
            background: var(--white);
            padding: 25px;
            border-radius: 10px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.05);
        }
        h2 {
            color: var(--primary-dark);
            margin-bottom: 25px;
            text-align: center;
        }
        label {
            display: block;
            margin-bottom: 8px;
            font-weight: 500;
            color: #555;
        }
        input, select {
            width: 100%;
            padding: 10px 15px;
            border: 1px solid #ddd;
            border-radius: 6px;
            font-family: 'Poppins', sans-serif;
            margin-bottom: 15px;
            font-size: 16px;
        }
        button {
            padding: 12px 20px;
            background-color: var(--primary-color);
            color: var(--white);
            border: none;
            border-radius: 6px;
            font-weight: 500;
            cursor: pointer;
            transition: all 0.3s;
            display: block;
            width: 100%;
        }
        button:hover {
            background-color: var(--primary-dark);
        }
        .btn-secondary {
            background-color: #6c757d;
            margin-top: 15px;
        }
        .btn-secondary:hover {
            background-color: #5a6268;
        }
    </style>
</head>
<body>
    <header>
        <h1>Editar Serviço</h1>
    </header>
    <div class="container">
        <form method="POST">
            <label for="nome">Nome do Serviço:</label>
            <input type="text" id="nome" name="nome" value="<?= htmlspecialchars($dados['nome']) ?>" required />
            
            <label for="preco">Preço:</label>
            <input type="number" step="0.01" id="preco" name="preco" value="<?= $dados['preco'] ?>" required />
            
            <label for="duracao">Duração (minutos):</label>
            <input type="number" id="duracao" name="duracao" value="<?= htmlspecialchars($dados['duracao']) ?>" required />
            
            <label for="produto">Produto:</label>
            <input type="text" id="produto" name="produto" value="<?= htmlspecialchars($dados['produto']) ?>" required />
            
            <label for="quantidade">Quantidade usada:</label>
            <input type="number" step="0.01" id="quantidade" name="quantidade" value="<?= $dados['quantidade_usada'] ?>" required />
            
            <button type="submit">Salvar</button>
        </form>
        <button class="btn-secondary" onclick="window.location.href='listar_servicos.php'">Cancelar</button>
    </div>
</body>
</html>
