<?php
require_once 'bootstrap.php';

if (!isset($_GET['id'])) {
    echo "ID do produto não especificado.";
    exit;
}

$id = intval($_GET['id']);

try {
    $pdo->beginTransaction();

    // Buscar todos os serviços que usam o produto
    $stmt = $pdo->prepare("SELECT DISTINCT servico_id FROM consumoproduto WHERE produto_id = :id");
    $stmt->execute([':id' => $id]);
    $servicos = $stmt->fetchAll(PDO::FETCH_COLUMN);

    // Para cada serviço, excluir consumos e o serviço
    foreach ($servicos as $servico_id) {
        // Excluir consumos do serviço
        $stmt = $pdo->prepare("DELETE FROM consumoproduto WHERE servico_id = :servico_id");
        $stmt->execute([':servico_id' => $servico_id]);

        // Excluir o serviço
        $stmt = $pdo->prepare("DELETE FROM servico WHERE id = :servico_id");
        $stmt->execute([':servico_id' => $servico_id]);
    }

    // Excluir o produto
    $stmt = $pdo->prepare("DELETE FROM produto WHERE id = :id");
    $stmt->execute([':id' => $id]);

    $pdo->commit();
    echo "Produto e serviços relacionados excluídos com sucesso.";
} catch (Exception $e) {
    $pdo->rollBack();
    echo "Erro ao excluir produto e serviços relacionados: " . $e->getMessage();
}
