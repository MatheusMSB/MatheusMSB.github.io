<?php
require_once 'bootstrap.php';

if (!isset($_GET['id'], $_GET['tipo'])) {
    die("Parâmetros inválidos.");
}

$servico_id = $_GET['id'];
$tipo_cabelo = $_GET['tipo'];

try {
    $pdo->beginTransaction();

    // Exclui consumo do produto
    $stmt = $pdo->prepare("DELETE FROM consumoproduto WHERE servico_id = :id AND tipo_cabelo = :tipo");
    $stmt->execute([
        ':id' => $servico_id,
        ':tipo' => $tipo_cabelo
    ]);

    // Verifica se o serviço ainda tem outros consumos (outros tipos de cabelo)
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM consumoproduto WHERE servico_id = :id");
    $stmt->execute([':id' => $servico_id]);
    $restantes = $stmt->fetchColumn();

    // Se não houver mais consumos, exclui o serviço
    if ($restantes == 0) {
        $stmt = $pdo->prepare("DELETE FROM servico WHERE id = :id");
        $stmt->execute([':id' => $servico_id]);
    }

    $pdo->commit();
    header("Location: listar_servicos.php");
    exit;
} catch (Exception $e) {
    $pdo->rollBack();
    die("Erro ao excluir serviço: " . $e->getMessage());
}
