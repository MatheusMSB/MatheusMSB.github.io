<?php
header('Content-Type: application/json');
require_once 'bootstrap.php'; // conexão com o banco de dados

$response = [
    'status' => 'erro',
    'mensagem' => 'Erro ao processar a solicitação.'
];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nome = trim($_POST['nome'] ?? '');
    $descricao = trim($_POST['descricao'] ?? '');
    $quantidade = intval($_POST['quantidade_disponivel'] ?? 0);

    if (empty($nome)) {
        $response['mensagem'] = 'O nome do produto é obrigatório.';
        echo json_encode($response);
        exit;
    }

    // Verifica se o produto já existe pelo nome
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM produto WHERE nome = ?");
    $stmt->execute([$nome]);
    $existe = $stmt->fetchColumn();

    if ($existe > 0) {
        $response['mensagem'] = 'Já existe um produto com este nome.';
        echo json_encode($response);
        exit;
    }

    // Insere o novo produto
    $stmt = $pdo->prepare("INSERT INTO produto (nome, descricao, quantidade_disponivel) VALUES (?, ?, ?)");
    if ($stmt->execute([$nome, $descricao, $quantidade])) {
        $response['status'] = 'sucesso';
        $response['mensagem'] = 'Produto adicionado com sucesso!';
    } else {
        $response['mensagem'] = 'Erro ao inserir o produto no banco de dados.';
    }

    echo json_encode($response);
} else {
    $response['mensagem'] = 'Requisição inválida.';
    echo json_encode($response);
}

