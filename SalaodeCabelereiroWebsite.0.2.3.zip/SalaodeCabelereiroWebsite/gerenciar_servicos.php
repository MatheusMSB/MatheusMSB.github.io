<?php
require_once 'bootstrap.php';

// Adicionar novo serviço
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['acao']) && $_POST['acao'] === 'adicionar') {
    if (!validate_csrf_token($_POST['csrf_token'] ?? '')) {
        die('Erro: Token CSRF inválido.');
    }
    $stmt = $pdo->prepare("INSERT INTO servico (nome, preco, descricao) VALUES (:nome, :preco, :descricao)");
    $stmt->execute([
        'nome' => $_POST['nome'],
        'preco' => $_POST['preco'],
        'descricao' => $_POST['descricao']
    ]);
    header("Location: gerenciar_servicos.php");
    exit;
}

// Atualizar serviço
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['acao']) && $_POST['acao'] === 'editar') {
    if (!validate_csrf_token($_POST['csrf_token'] ?? '')) {
        die('Erro: Token CSRF inválido.');
    }
    $stmt = $pdo->prepare("UPDATE servico SET nome = :nome, preco = :preco, descricao = :descricao WHERE id = :id");
    $stmt->execute([
        'nome' => $_POST['nome'],
        'preco' => $_POST['preco'],
        'descricao' => $_POST['descricao'],
        'id' => $_POST['id']
    ]);
    header("Location: gerenciar_servicos.php");
    exit;
}

// Excluir serviço
if (isset($_GET['deletar_id'])) {
    // CSRF token validation for GET requests is recommended but not implemented here
    $stmt = $pdo->prepare("DELETE FROM servico WHERE id = :id");
    $stmt->execute(['id' => $_GET['deletar_id']]);
    header("Location: gerenciar_servicos.php");
    exit;
}

// Buscar todos os serviços
$servicos = $pdo->query("SELECT * FROM servico ORDER BY id DESC")->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Gerenciar Serviços</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; }
        table { width: 100%; border-collapse: collapse; margin-top: 20px; }
        th, td { border: 1px solid #ccc; padding: 8px; text-align: left; }
        th { background-color: #f5f5f5; }
        form.inline { display: inline; }
        input[type="text"], input[type="number"], textarea { width: 100%; }
    </style>
</head>
<body>
    <h2>Adicionar Novo Serviço</h2>
    <form method="POST">
        <input type="hidden" name="acao" value="adicionar">
        <label>Nome:<br><input type="text" name="nome" required></label><br><br>
        <label>Preço:<br><input type="number" step="0.01" name="preco" required></label><br><br>
        <label>Descrição:<br><textarea name="descricao" rows="3" required></textarea></label><br><br>
        <button type="submit">Adicionar Serviço</button>
    </form>

    <h2>Serviços Cadastrados</h2>
    <table>
        <tr>
            <th>Nome</th>
            <th>Preço (R$)</th>
            <th>Descrição</th>
            <th>Ações</th>
        </tr>
        <?php foreach ($servicos as $s): ?>
        <tr>
            <form method="POST">
                <input type="hidden" name="acao" value="editar">
                <input type="hidden" name="id" value="<?= htmlspecialchars($s['id']) ?>">
                <td><input type="text" name="nome" value="<?= htmlspecialchars($s['nome']) ?>" required></td>
                <td><input type="number" step="0.01" name="preco" value="<?= htmlspecialchars($s['preco']) ?>" required></td>
                <td><textarea name="descricao" rows="2" required><?= htmlspecialchars($s['descricao']) ?></textarea></td>
                <td>
                    <button type="submit">Salvar</button>
                    <a href="?deletar_id=<?= htmlspecialchars($s['id']) ?>" onclick="return confirm('Excluir este serviço?')">Deletar</a>
                </td>
            </form>
        </tr>
        <?php endforeach; ?>
    </table>
</body>
</html>
