-- Criação da tabela de usuários com função (role)
CREATE TABLE user (
  id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(50) NOT NULL UNIQUE,
  password VARCHAR(255) NOT NULL,
  email VARCHAR(100) NOT NULL UNIQUE,
  role VARCHAR(20) NOT NULL DEFAULT 'customer',
  CONSTRAINT CK_users_role CHECK (role IN ('customer', 'admin', 'client', 'administrator'))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE INDEX idx_user_role ON user(role);

-- Tabela de clientes com chave estrangeira para user
CREATE TABLE cliente (
  id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
  nome VARCHAR(100) NOT NULL,
  user_id INT DEFAULT NULL,
  INDEX idx_cliente_user_id(user_id),
  CONSTRAINT FK_cliente_user FOREIGN KEY (user_id) REFERENCES user(id) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Tabela de serviços
CREATE TABLE servico (
  id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
  nome VARCHAR(100) NOT NULL,
  preco DECIMAL(10,2) NOT NULL,
  duracao INT DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Tabela de produtos
CREATE TABLE produto (
  id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
  nome VARCHAR(100) NOT NULL,
  descricao TEXT DEFAULT NULL,
  quantidade_disponivel INT NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Tabela de horários disponíveis
CREATE TABLE horariodisponivel (
  id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
  data DATE NOT NULL,
  hora_inicio TIME NOT NULL,
  hora_fim TIME NOT NULL,
  disponivel BIT DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Tabela de agendamentos (somente pode referenciar clientes válidos)
CREATE TABLE agendamento (
  id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
  cliente_id INT DEFAULT NULL,
  servico_id INT DEFAULT NULL,
  horario_disponivel_id INT DEFAULT NULL,
  data DATE NOT NULL,
  hora_inicio TIME NOT NULL,
  hora_fim TIME NOT NULL,
  disponivel BIT DEFAULT 1,
  alterado_pelo_admin BIT DEFAULT 0,
  observacao TEXT DEFAULT NULL,
  INDEX idx_agendamento_cliente_id(cliente_id),
  INDEX idx_agendamento_servico_id(servico_id),
  INDEX idx_agendamento_horario_disponivel_id(horario_disponivel_id),
  CONSTRAINT FK_agendamento_cliente FOREIGN KEY (cliente_id) REFERENCES cliente(id) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT FK_agendamento_servico FOREIGN KEY (servico_id) REFERENCES servico(id) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT FK_agendamento_horariodisponivel FOREIGN KEY (horario_disponivel_id) REFERENCES horariodisponivel(id) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Tabela de consumo de produtos por serviço e tipo de cabelo
CREATE TABLE consumoproduto (
  id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
  produto_id INT NOT NULL,
  servico_id INT NOT NULL,
  tipo_cabelo VARCHAR(50) NOT NULL,
  quantidade_usada DECIMAL(10,2) NOT NULL,
  INDEX idx_consumoproduto_produto_id(produto_id),
  INDEX idx_consumoproduto_servico_id(servico_id),
  CONSTRAINT FK_consumoproduto_produto FOREIGN KEY (produto_id) REFERENCES produto(id) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT FK_consumoproduto_servico FOREIGN KEY (servico_id) REFERENCES servico(id) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Tabela de duração de serviço por tipo de cabelo
CREATE TABLE duracaoservico (
  id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
  servico_id INT NOT NULL,
  tipo_cabelo VARCHAR(50) NOT NULL,
  duracao_minutos INT NOT NULL,
  INDEX idx_duracaoservico_servico_id(servico_id),
  CONSTRAINT FK_duracaoservico_servico FOREIGN KEY (servico_id) REFERENCES servico(id) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
