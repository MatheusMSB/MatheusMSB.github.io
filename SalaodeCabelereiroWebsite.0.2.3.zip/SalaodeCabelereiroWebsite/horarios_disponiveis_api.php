<?php
include('database.php');

$data = $_GET['data'];

$sql = "SELECT hora_inicio FROM horariodisponivel 
        WHERE data = ? AND disponivel = 1";
$stmt = $conn->prepare($sql);
$stmt->bind_param('s', $data);
$stmt->execute();
$result = $stmt->get_result();

$horarios = [];
while ($row = $result->fetch_assoc()) {
    $horarios[] = ['hora_inicio' => substr($row['hora_inicio'], 0, 5)];
}

header('Content-Type: application/json');
echo json_encode($horarios);
?>
