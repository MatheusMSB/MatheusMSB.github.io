<?php
require_once 'bootstrap.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!validate_csrf_token($_POST['csrf_token'] ?? '')) {
        echo json_encode(['success' => false, 'message' => 'Erro: Token CSRF inválido.']);
        exit;
    }

    $productId = $_POST['product_id'] ?? null;
    $quantity = $_POST['quantity'] ?? null;

    if ($productId === null || $quantity === null) {
        echo json_encode(['success' => false, 'message' => 'Missing product_id or quantity']);
        exit;
    }

    $quantity = intval($quantity);
    if ($quantity < 0) {
        echo json_encode(['success' => false, 'message' => 'Quantity cannot be negative']);
        exit;
    }

    $stmt = $pdo->prepare("UPDATE produto SET quantidade_disponivel = ? WHERE id = ?");
    if ($stmt->execute([$quantity, $productId])) {
        echo json_encode(['success' => true, 'message' => 'Inventory updated successfully']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Failed to update inventory']);
    }
} else {
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
}
?>
