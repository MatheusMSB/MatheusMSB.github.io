<?php
require_once 'bootstrap.php';
header('Content-Type: application/json');

try {
    $stmt = $pdo->query("SELECT * FROM produto ORDER BY id DESC");
    $produtos = $stmt->fetchAll(PDO::FETCH_ASSOC);
    echo json_encode($produtos);
} catch (Exception $e) {
    echo json_encode(["erro" => "Erro ao listar produtos: " . $e->getMessage()]);
}
?>
