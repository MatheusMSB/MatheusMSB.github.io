<?php
require_once 'bootstrap.php';

try {
    $sql = "SELECT 
                s.id AS servico_id,
                s.nome AS nome_servico,
                s.preco,
                s.duracao,
                p.nome AS nome_produto,
                c.tipo_cabelo,
                c.quantidade_usada
            FROM servico s
            JOIN consumoproduto c ON c.servico_id = s.id
            JOIN produto p ON p.id = c.produto_id
            ORDER BY s.nome, c.tipo_cabelo";

    $stmt = $pdo->query($sql);
    $servicos = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (Exception $e) {
    die("Erro ao buscar serviços: " . $e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Lista de Serviços</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600&display=swap" rel="stylesheet" />
    <style>
        body {
            font-family: 'Poppins', sans-serif;
            background-color: #f8f9fa;
            margin: 0;
            padding: 20px;
            color: #333;
        }
        h1 {
            text-align: center;
            color: #2e7d32;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            background: white;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            border-radius: 10px;
            overflow: hidden;
        }
        th, td {
            padding: 12px 16px;
            border-bottom: 1px solid #ddd;
            text-align: left;
        }
        th {
            background-color: #388e3c;
            color: white;
        }
        tr:hover {
            background-color: #f1f1f1;
        }
        .back-btn {
            display: inline-block;
            margin: 20px 0;
            padding: 10px 18px;
            background-color: #388e3c;
            color: white;
            text-decoration: none;
            border-radius: 6px;
            transition: background 0.3s;
        }
        .back-btn:hover {
            background-color: #2e7d32;
        }
    </style>
</head>
<body>
    <h1>Serviços Cadastrados</h1>

    <a class="back-btn" href="registrar_servico.html">← Voltar para Serviços</a>

    <table>
        <thead>
            <tr>
                <th>Nome do Serviço</th>
                <th>Tipo de Cabelo</th>
                <th>Preço (R$)</th>
                <th>Duração (minutos)</th>
                <th>Produto Utilizado</th>
                <th>Quantidade Usada</th>
                <th>Ações</th>
            </tr>
        </thead>
        <tbody>
            <?php if (count($servicos) > 0): ?>
                <?php foreach ($servicos as $servico): ?>
                    <tr>
                        <td><?= htmlspecialchars($servico['nome_servico']) ?></td>
                        <td><?= htmlspecialchars($servico['tipo_cabelo']) ?></td>
                        <td><?= number_format($servico['preco'], 2, ',', '.') ?></td>
                        <td><?= htmlspecialchars($servico['duracao']) ?></td>
                        <td><?= htmlspecialchars($servico['nome_produto']) ?></td>
                        <td><?= htmlspecialchars($servico['quantidade_usada']) ?></td>
                        <td>
                            <a href="editar_servico.php?id=<?= $servico['servico_id'] ?>&tipo=<?= $servico['tipo_cabelo'] ?>">Editar</a> |
                            <a href="excluir_servico.php?id=<?= $servico['servico_id'] ?>&tipo=<?= $servico['tipo_cabelo'] ?>"
                            onclick="return confirm('Tem certeza que deseja excluir este serviço para esse tipo de cabelo?');">Excluir</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            <?php else: ?>
                <tr><td colspan="7" style="text-align:center;">Nenhum serviço cadastrado.</td></tr>
            <?php endif; ?>
        </tbody>

    </table>
</body>
</html>
