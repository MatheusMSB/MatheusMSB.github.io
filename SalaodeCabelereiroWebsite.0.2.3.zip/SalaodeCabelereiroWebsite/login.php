<?php
session_start();
require_once 'database.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Tenta ler como JSON (fetch)
    $data = json_decode(file_get_contents('php://input'), true);

    if ($data) {
        $username = trim($data['username'] ?? '');
        $password = trim($data['password'] ?? '');
    } else {
        // Se não for JSON, tenta como formulário HTML
        $username = trim($_POST['username'] ?? '');
        $password = trim($_POST['password'] ?? '');
    }

    if (empty($username) || empty($password)) {
        echo json_encode(['success' => false, 'message' => 'Usuário e senha são obrigatórios.']);
        exit;
    }

    // Busca o usuário
    $stmt = $pdo->prepare("SELECT * FROM `user` WHERE username = ?");
    $stmt->execute([$username]);
    $user = $stmt->fetch();

    if ($user && password_verify($password, $user['password'])) {
        $_SESSION['user'] = [
            'id' => $user['id'],
            'username' => $user['username'],
            'role' => $user['role'] ?? 'customer'
        ];
       $redirect = ($user['role'] === 'admin') ? 'admin_schedule.html' : 'scheduling.html';
        echo json_encode([
            'success' => true,
            'message' => 'Login realizado com sucesso.',
            'redirect_url' => $redirect
        ]);

        
    } else {
        echo json_encode(['success' => false, 'message' => 'Usuário ou senha inválidos.']);
    }

} else {
    echo json_encode(['success' => false, 'message' => 'Método de requisição inválido.']);
}
?>
