<?php

require_once 'database.php';
session_start();

// Detecta se a requisição veio de um formulário HTML ou JSON
$isJson = true; // Always respond with JSON for AJAX

$data = json_decode(file_get_contents('php://input'), true);

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $data) {
    $username = trim($data['username'] ?? '');
    $email = trim($data['email'] ?? '');
    $password = trim($data['password'] ?? '');
    $role = strtolower(trim($data['role'] ?? 'client'));

    if (empty($username) || empty($email) || empty($password)) {
        $response = ['success' => false, 'message' => 'Todos os campos são obrigatórios.'];
        exitWithResponse($response, $isJson);
    }

    // Aceita apenas 'client' ou 'admin'
    $allowed_roles = ['client', 'admin'];
    if (!in_array($role, $allowed_roles)) {
        $role = 'client';
    }

    // Verifica se usuário ou e-mail já existem
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM `user` WHERE username = ? OR email = ?");
    $stmt->execute([$username, $email]);
    if ($stmt->fetchColumn() > 0) {
        $response = ['success' => false, 'message' => 'Usuário ou e-mail já existem.'];
        exitWithResponse($response, $isJson);
    }

    $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

    $stmt = $pdo->prepare("INSERT INTO `user` (username, email, password, role) VALUES (?, ?, ?, ?)");
    if ($stmt->execute([$username, $email, $hashedPassword, $role])) {
        // Cadastro ok, inicia sessão
        $_SESSION['username'] = $username;
        $_SESSION['role'] = $role;

        // Se o usuário for client, inserir na tabela cliente
        if ($role === 'client') {
            $user_id = $pdo->lastInsertId();
            $stmt_cliente = $pdo->prepare("INSERT INTO cliente (user_id, nome) VALUES (?, ?)");
            $stmt_cliente->execute([$user_id, $username]);
        }

        $response = ['success' => true, 'message' => 'Cadastro realizado com sucesso.'];
    } else {
        $response = ['success' => false, 'message' => 'Erro ao registrar.'];
    }

    exitWithResponse($response, $isJson);
} else {
    $response = ['success' => false, 'message' => 'Método de requisição inválido.'];
    exitWithResponse($response, $isJson);
}

function exitWithResponse($response, $isJson) {
    if ($isJson) {
        header('Content-Type: application/json');
        echo json_encode($response);
    } else {
        if ($response['success']) {
            echo "<p style='color: green; text-align:center; margin: 20px 0;'>{$response['message']}</p>";
        } else {
            echo "<p style='color: red; text-align:center; margin: 20px 0;'>{$response['message']}</p>";
        }
    }
    exit;
}
