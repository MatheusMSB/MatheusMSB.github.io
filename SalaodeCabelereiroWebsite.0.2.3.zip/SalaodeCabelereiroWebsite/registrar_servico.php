<?php
require_once 'bootstrap.php';

// Removed login check to allow service registration without login
/*
if (!isset($_SESSION['user_id'])) {
    http_response_code(403);
    echo "Acesso negado. Por favor, faça login para continuar.";
    exit;
}
*/

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: registrar_servico_form.php'); // redirect to new form page
    exit;
}

$nome = trim($_POST['serviceName']);
$duracao_str = $_POST['duration'];
$preco = $_POST['preco'];
$produto_nome = trim($_POST['product']);
$quantidade = floatval($_POST['productAmount']);
$tipo_cabelo = $_POST['tipoCabelo'];

// Verifica se campos obrigatórios estão vazios
if (empty($nome) || empty($duracao_str) || empty($preco) || empty($produto_nome) || empty($tipo_cabelo)) {
    echo "Todos os campos obrigatórios devem ser preenchidos.";
    exit;
}

// Convert duration string "HH:MM" to total minutes as integer
list($hours, $minutes) = explode(':', $duracao_str);
$duracao = intval($hours) * 60 + intval($minutes);

try {
    $pdo->beginTransaction();

    // Obter o produto existente, não inserir novo produto
    $stmt = $pdo->prepare("SELECT id FROM produto WHERE nome = :nome LIMIT 1");
    $stmt->execute([':nome' => $produto_nome]);
    $produto = $stmt->fetch();

    if (!$produto) {
        // Produto não encontrado, erro
        throw new Exception("Produto não encontrado. Por favor, registre o produto primeiro na página de gerenciamento de produtos.");
    }

    $produto_id = $produto['id'];

    // Inserir o serviço
    $stmt = $pdo->prepare("INSERT INTO servico (nome, preco, duracao) VALUES (:nome, :preco, :duracao)");
    $stmt->execute([
        ':nome' => $nome,
        ':preco' => $preco,
        ':duracao' => $duracao
    ]);
    $servico_id = $pdo->lastInsertId();

    // Inserir consumo do produto
    $stmt = $pdo->prepare("INSERT INTO consumoproduto (servico_id, produto_id, tipo_cabelo, quantidade_usada) VALUES (:servico_id, :produto_id, :tipo_cabelo, :quantidade_usada)");
    $stmt->execute([
        ':servico_id' => $servico_id,
        ':produto_id' => $produto_id,
        ':tipo_cabelo' => $tipo_cabelo,
        ':quantidade_usada' => $quantidade
    ]);

    $pdo->commit();
    header('Location: registrar_servico.html?success=1');
    exit;
} catch (Exception $e) {
    $pdo->rollBack();
    echo "Erro ao registrar serviço: " . $e->getMessage();
}
