<?php
require_once 'bootstrap.php';

// Fetch products from the database
try {
    $stmt = $pdo->query("SELECT id, nome FROM produto ORDER BY nome ASC");
    $products = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (Exception $e) {
    $products = [];
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Registrar Serviço - Salão de Cabeleireiro</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600&display=swap" rel="stylesheet" />
    <style>
        :root {
            --primary-color: #388e3c;
            --primary-dark: #2e7d32;
            --light-bg: #f8f9fa;
        }
        body {
            font-family: 'Poppins', sans-serif;
            margin: 0;
            padding: 0;
            background-color: var(--light-bg);
            color: #333;
        }
        header {
            background-color: var(--primary-color);
            color: white;
            padding: 20px 0;
            text-align: center;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        header h1 {
            margin: 0;
            font-weight: 600;
        }
        .container {
            max-width: 600px;
            margin: 40px auto;
            padding: 0 20px;
        }
        .form-card {
            background: white;
            border-radius: 10px;
            box-shadow: 0 2px 15px rgba(0,0,0,0.05);
            padding: 30px;
        }
        h2 {
            color: var(--primary-dark);
            margin-top: 0;
            margin-bottom: 25px;
            text-align: center;
            font-weight: 500;
        }
        .form-group {
            margin-bottom: 20px;
        }
        label {
            display: block;
            margin-bottom: 8px;
            font-weight: 500;
            color: #555;
        }
        select, input[type="text"], input[type="number"] {
            width: 100%;
            padding: 12px 15px;
            border: 1px solid #ddd;
            border-radius: 6px;
            font-family: 'Poppins', sans-serif;
            font-size: 16px;
        }
        select:focus, input[type="text"]:focus, input[type="number"]:focus {
            border-color: var(--primary-color);
            outline: none;
            box-shadow: 0 0 0 3px rgba(56, 142, 60, 0.2);
        }
        button {
            width: 100%;
            padding: 14px;
            background-color: var(--primary-color);
            color: white;
            border: none;
            border-radius: 6px;
            font-size: 16px;
            font-weight: 500;
            cursor: pointer;
            transition: background 0.3s;
            margin-top: 10px;
        }
        button:hover {
            background-color: var(--primary-dark);
        }
        .no-products {
            color: red;
            font-weight: 600;
            margin-bottom: 20px;
            text-align: center;
        }
    </style>
</head>
<body>
    <header>
        <h1>Registrar Serviço</h1>
    </header>
    <div class="container">
        <div class="form-card">
            <h2>Cadastro de Novo Serviço</h2>

            <!-- Botão para listar serviços -->
            <form action="listar_servicos.php" method="GET" style="margin-bottom: 20px;">
                <button type="submit" style="background-color: #555;">Listar Serviços</button>
            </form>

            <?php if (count($products) === 0): ?>
                <div class="no-products">Nenhum produto cadastrado disponível para seleção.</div>
            <?php endif; ?>

            <form id="registerServiceForm" action="registrar_servico.php" method="POST">
                <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_token'] ?? '') ?>">

                <div class="form-group">
                    <label for="serviceName">Nome do Serviço:</label>
                    <input type="text" id="serviceName" name="serviceName" required />
                </div>
                <div class="form-group">
                    <label for="tipoCabelo">Tipo de Cabelo:</label>
                    <select id="tipoCabelo" name="tipoCabelo" required>
                        <option value="">Selecione o tipo</option>
                        <option value="P">Pequeno</option>
                        <option value="M">Médio</option>
                        <option value="G">Grande</option>
                    </select>
                </div>

                <div class="form-group">
                    <label for="preco">Preço do Serviço (R$):</label>
                    <input type="number" id="preco" name="preco" min="0" step="0.01" required />
                </div>

                <div class="form-group">
                    <label for="duration">Tempo de Duração:</label>
                    <select id="duration" name="duration" required>
                        <option value="">Selecione a duração</option>
                        <option value="00:30">00:30</option>
                        <option value="01:00">01:00</option>
                        <option value="01:30">01:30</option>
                        <option value="02:00">02:00</option>
                        <option value="02:30">02:30</option>
                        <option value="03:00">03:00</option>
                        <option value="03:30">03:30</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="product">Produto Utilizado:</label>
                    <select id="product" name="product" required <?php if (count($products) === 0) echo 'disabled'; ?>>
                        <option value="">Selecione um produto</option>
                        <?php foreach ($products as $product): ?>
                            <option value="<?= htmlspecialchars($product['nome']) ?>"><?= htmlspecialchars($product['nome']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="form-group">
                    <label for="productAmount">Quantidade do Produto:</label>
                    <input type="number" id="productAmount" name="productAmount" min="0" step="any" required <?php if (count($products) === 0) echo 'disabled'; ?> />
                </div>
                <button type="submit" <?php if (count($products) === 0) echo 'disabled'; ?>>Registrar Serviço</button>
            </form>
            <div style="margin-top: 30px;">
                <button onclick="window.location.href='admin_schedule.html'">Voltar para Administração</button>
            </div>
        </div>
    </div>
    <script>
        // Show success message if ?success=1 is in URL
        const urlParams = new URLSearchParams(window.location.search);
        if (urlParams.get('success') === '1') {
            const container = document.querySelector('.container');
            const messageDiv = document.createElement('div');
            messageDiv.textContent = 'Serviço registrado com sucesso.';
            messageDiv.style.backgroundColor = '#d4edda';
            messageDiv.style.color = '#155724';
            messageDiv.style.border = '1px solid #c3e6cb';
            messageDiv.style.padding = '15px';
            messageDiv.style.marginBottom = '25px';
            messageDiv.style.borderRadius = '5px';
            messageDiv.style.fontWeight = '600';
            messageDiv.style.fontFamily = "'Poppins', sans-serif";
            messageDiv.style.fontSize = '16px';
            messageDiv.style.textAlign = 'center';
            container.insertBefore(messageDiv, container.firstChild);
        }
    </script>
</body>
</html>
