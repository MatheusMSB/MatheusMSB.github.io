<?php
require_once 'database.php';

header('Content-Type: application/json');

try {
    $stmt = $pdo->query("SELECT id, nome FROM servico ORDER BY nome");
    $services = $stmt->fetchAll(PDO::FETCH_ASSOC);
    echo json_encode(['success' => true, 'services' => $services]);
} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => 'Erro ao buscar serviços']);
}
?>
