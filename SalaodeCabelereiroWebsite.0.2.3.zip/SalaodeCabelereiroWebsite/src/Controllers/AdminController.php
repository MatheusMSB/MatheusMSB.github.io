<?php
namespace Controllers;

require_once __DIR__ . '/../../database.php';
require_once __DIR__ . '/../Middlewares/AuthMiddleware.php';

use Middlewares\AuthMiddleware;

// Require user to be an administrator
AuthMiddleware::requireRole('admin');

try {
    $stmt = $pdo->prepare("
        SELECT a.id, u.name AS client, a.service, a.appointment_datetime, a.status
        FROM appointments a
        JOIN users u ON u.id = a.user_id
        ORDER BY a.appointment_datetime DESC
    ");
    $stmt->execute();
    $appointments = $stmt->fetchAll();
} catch (\PDOException $e) {
    // Handle database error gracefully
    die("Database error: " . htmlspecialchars($e->getMessage()));
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8" />
    <title>Agenda - Administrador</title>
    <link rel="stylesheet" href="styles.css" />
</head>
<body>
    <h1>Agenda de Agendamentos</h1>
    <table border="1" cellpadding="5" cellspacing="0">
        <thead>
            <tr>
                <th>ID</th>
                <th>Cliente</th>
                <th>Serviço</th>
                <th>Data e Hora</th>
                <th>Status</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($appointments as $app): ?>
            <tr>
                <td><?= htmlspecialchars($app['id']) ?></td>
                <td><?= htmlspecialchars($app['client']) ?></td>
                <td><?= htmlspecialchars($app['service']) ?></td>
                <td><?= htmlspecialchars($app['appointment_datetime']) ?></td>
                <td><?= htmlspecialchars($app['status']) ?></td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
    <p><a href="gerenciar_produtos.php">Gerenciar Produtos</a></p>
</body>
</html>
