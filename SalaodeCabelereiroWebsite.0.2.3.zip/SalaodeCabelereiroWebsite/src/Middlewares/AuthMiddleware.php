<?php
namespace Middlewares;

class AuthMiddleware {
    public static function requireRole($role) {
        session_start();
        if (!isset($_SESSION['user']) || strcasecmp($_SESSION['user']['role'], $role) !== 0) {
            header('Location: /login.html');
            exit();
        }
    }
}
?>
